import styles from './resetPassword.module.scss'

const ResetPassword = () => {
    return (
        <div className={styles['reset-password-container']}>ResetPassword</div>
    )
}

export default ResetPassword