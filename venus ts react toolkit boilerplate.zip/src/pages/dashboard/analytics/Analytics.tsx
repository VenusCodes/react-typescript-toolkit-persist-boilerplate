import styles from './analytics.module.scss'

const Analytics = () => {
    return (
        <div className={styles['analytics-container']}>Analytics</div>
    )
}

export default Analytics