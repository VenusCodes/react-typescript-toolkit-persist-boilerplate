import styles from './login.module.scss'

const Login = () => {
    return (
        <div className={styles['login-container']}>Login</div>
    )
}

export default Login