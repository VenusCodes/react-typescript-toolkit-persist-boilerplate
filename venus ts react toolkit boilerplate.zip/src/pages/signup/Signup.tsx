import styles from './signup.module.scss'

const Signup = () => {
    return (
        <div className={styles['signup-container']}>Signup</div>
    )
}

export default Signup