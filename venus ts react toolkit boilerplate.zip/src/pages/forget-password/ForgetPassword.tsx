import styles from './forgetPassword.module.scss'

const ForgetPassword = () => {
    return (
        <div className={styles['forget-password-container']}>ForgetPassword</div>
    )
}

export default ForgetPassword