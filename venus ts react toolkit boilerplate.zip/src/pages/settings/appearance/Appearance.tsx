import styles from './appearance.module.scss'

const Appearance = () => {
    return (
        <div className={styles['appearance-container']}>Appearance</div>
    )
}

export default Appearance