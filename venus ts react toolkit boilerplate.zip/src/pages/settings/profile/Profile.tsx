import styles from './profile.module.scss'

const Profile = () => {
    return (
        <div className={styles['profile-container']}>Profile</div>
    )
}

export default Profile