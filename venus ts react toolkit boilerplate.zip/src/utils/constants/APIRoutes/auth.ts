export enum AUTH_API_ROUTES {
    LOGIN = '/user/login'
} 