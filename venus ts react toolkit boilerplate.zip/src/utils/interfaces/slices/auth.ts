
export interface authState {
    email: string,
    token: string,
    //more data...
}